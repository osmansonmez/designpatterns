﻿using System;

namespace DoFactory.GangOfFour
{
    public class GoFException : Exception
    {
        public GoFException(string message) : base(message)
        {
        }
    }
}
